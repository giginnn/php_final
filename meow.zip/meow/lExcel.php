<meta charset="utf-8">
<?php
header("Pragma: public");
header("Expires: 0");
header('Cache-Control: must-revalidate, post-check=0, pre-check=0'); 
header('Content-type: application/vnd.ms-excel');
header('Content-Disposition: inline; filename="2024本月銷售總額.xls";');
header('Content-Transfer-Encoding: binary');

echo "<table border='1'>";
echo "<tr>";
echo "<td>日期</td>";
echo "<td>總銷售額</td>";
echo "</tr>";
// 連接資料庫
$link = mysqli_connect('localhost','root','','meow');

$sql = "SELECT DATE_FORMAT(shoppingorder.time, '%m-%d') AS formatted_date, SUM(detail.total) AS total 
        FROM detail 
        NATURAL JOIN shoppingorder 
        GROUP BY formatted_date 
        ORDER BY shoppingorder.time";
$result = mysqli_query($link, $sql);
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>".$row["formatted_date"]."</td>";
    echo "<td>".$row["total"]."</td>";
    echo "</tr>";
}
?>