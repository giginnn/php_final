<?php
include("include.inc");
?>

<html>
  <head>
    <meta charset="utf8">
    <title>銷售額折線圖</title>
      <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
      <link rel="stylesheet" href="assets/css/main.css" />
      <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
  </head>

  <body class="is-preload">
    <div id="wrapper">
      <header id="header">
        <div class="inner">
          <div class="logo">
            <span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">2024本月銷售總額折線圖</span>
          </div>
      </header>
    <div id="main">
  <div class="inner">

<?php
$link = mysqli_connect('localhost','root','','meow');

$sql = "SELECT DATE_FORMAT(shoppingorder.time, '%m-%d') AS formatted_date, SUM(detail.total) AS total 
        FROM detail 
        NATURAL JOIN shoppingorder 
        GROUP BY formatted_date 
        ORDER BY shoppingorder.time";
$result = mysqli_query($link, $sql);
?>

<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Date', 'Total'],
          <?php
            $data_rows = [];
            while($row=mysqli_fetch_assoc($result)){
                $date = $row["formatted_date"];
                $total = $row["total"];
                $data_rows[] = "['$date', $total]";
            }
            echo implode(",", $data_rows);
          ?>
        ]);

        var options = {
          title: '<?php echo date('Y'); ?>本月銷售總額',
          curveType: 'function',
          legend: { position: 'bottom' },
          hAxis: { 
            title: '日期',
            format: 'MM-dd',
            gridlines: { count: 15 }
          },
          vAxis: {
            title: '總額'
          }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="curve_chart" style="width: 900px; height: 500px"></div>
  </body>
</html>

<div class='col-12'>
  <ul class='actions fit'>
    <li><a href = 'bossPage.php' class='button primary'>回上一頁</a></li>
    <li><a href = 'piechart.php' class='button'>銷售量圓餅圖</a></li>
    <li><a href = 'lExcel.php' class='button'>下載成Excel</a></li>
    <li><a href = 'lPdf.php' class='button'>下載成PDF</a></li>
    <li><a href = 'logout.php' class='button primary'>登出</a></li>
  </ul>
</div>
</div></div></div></body></html>
