<?php
include("include.inc");
?>
<html>
<head>
<title>管理會員</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">菜單資料庫</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">   
<?php
$link = mysqli_connect('localhost', 'root', '', 'meow');

$sql = "SELECT mem.mId FROM member AS mem";

$result = mysqli_query($link, $sql);

$Data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $Data[] = ['會員'=>$row['mId']];
}


?>


<h2>所有會員</h2>
<div class='table-wrapper'>
    <table>
        <thead>
            <tr>
                <th>會員</th>
        </thead>

        <tbody>
            <?php foreach ($Data as $order): ?>
            <tr>
                <td><?php echo htmlspecialchars($order['會員']); ?></td>
                <td><a href = 'memDel.php?mId=<?php echo htmlspecialchars($order['會員']); ?>'>刪除</a></td>
            </tr>
            <?php endforeach;
            mysqli_close($link); ?>
        </tbody>
    </table>
</div>

<?php
echo
"<ul class='actions fit'>";
if($_SESSION["check"]=="staff")
{
    echo
    "<li><a href ='staffPage.php' class='button'>回上一頁</a></li>";
}elseif($_SESSION["check"]=="boss")
{
    echo
    "<li><a href ='bossPage.php' class='button'>回上一頁</a></li>";
}
echo "<li><a href ='logout.php' class='button fit'>登出</a></li>
</ul>";
?>
</div></div></div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body></html>
