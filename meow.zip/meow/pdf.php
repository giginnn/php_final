<?php
    ob_start();
?>
<meta charset="utf-8">  
<?php

require_once('TCPDF/tcpdf.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// set font
$pdf->SetFont('msungstdlight', '', 10);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->AddPage();

$link=mysqli_connect(
    'localhost',
    'root',
    '',
    'college'

);

$sql="SELECT * FROM student";
$result=mysqli_query($link,$sql);

$html='<table border="1">';
$html.='<tr><td>編號</td><td>姓名</td><td>系所</td></tr>';

while($row=mysqli_fetch_assoc($result)){
$html.="<tr>";
$html.="<td>".$row["No"]."</td><td>".$row["Name"]."</td><td>".$row["Department"]."</td>";
$html.="</tr>";
 };
$html.="</table>";


// output the HTML content
$pdf->writeHTML($html);
//file send to file address
$path = "/123info.pdf";
ob_end_clean();
//Close and output PDF document
$pdf->Output(__DIR__ .$path, 'D');
//$pdf->Output($No."-tableinfo.pdf", 'D');
ob_end_flush();

?>