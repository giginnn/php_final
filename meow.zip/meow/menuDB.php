<?php
include("include.inc");
?>
<html>
<head>
<title>菜單資料庫</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">菜單資料庫</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">

<?php
if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="staff" || $_SESSION["check"]=="boss"){
        // echo "成功<br/>";
        echo "<h3>資料庫詳細資訊</h3>";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
}
?>


<?php
//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "SELECT * FROM menu";
//送出查詢
$result = mysqli_query($link,$sql);
//結果轉陣列
echo "<table border = '1'>";
while($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td>".$row["menuId"]."</td>
    <td>".$row["mName"]."</td>
    <td>".$row["mPrice"]."元/份"."</td>
    <td>"."檔案位置：".$row["mPicture"]."</td>
    <td>"."菜品描述：".$row["mWord"]."</td>
    <td><a href = 'menuDel.php?menuId=".$row["menuId"]."'>刪除</a>"."</td>
    <td><a href = 'menuUpdate.php?menuId=".$row["menuId"]."'>修改</a></td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($link);

echo
"<ul class='actions fit'>
<li><a href ='menuAdd.php' class='button primary'>新增菜單</a></li>";
if($_SESSION["check"]=="staff")
{
    echo
    "<li><a href ='staffPage.php' class='button'>回上一頁</a></li>";
}elseif($_SESSION["check"]=="boss")
{
    echo
    "<li><a href ='bossPage.php' class='button'>回上一頁</a></li>";
}
echo "<li><a href ='logout.php' class='button fit'>登出</a></li>
</ul>";
?>   
</div></div></div></body></html>