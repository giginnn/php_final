<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf8">
<title>料理喵王訂購資訊確認</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王訂單資訊</span>

<nav>
<ul>
<li><a href="#menu">Menu</a></li>
</ul>
</nav>
</div>
</header>

<nav id="menu">
<h2>選單</h2>
<ul>
<li><a href="menumember.php">首頁</a></li>
<li><a href="historyorder.php">訂單紀錄</a></li>
<li><a href="logout.php">登出</a></li>
</ul>
</nav>

<div id="main">
<div class="inner">

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST as $key => $value) {
        $_SESSION[$key] = $value;
    }
}
$link = mysqli_connect('localhost', 'root', '', 'meow');

$mId = $_SESSION["mId"] ?? null;

if (!$mId) {
    die("您尚未登入！");
}

echo "<h3>$mId 的訂單資訊</h3>";
echo "<form method='post' action='cartcheck.php'>";
echo "<div class='table-wrapper'>
    <table>
        <thead>
            <tr>
                <th>餐點名稱</th>
                <th>數量</th>
                <th>金額</th>
            </tr>
        </thead>";

$totalPrice = 0;

foreach ($_SESSION as $key => $value) {
    if (strpos($key, 'item_') === 0 && $value > 0) {
        $menuId = substr($key, 5);
        $result = mysqli_query($link, "SELECT mName, mPrice FROM menu WHERE menuId = $menuId");
        if ($row = mysqli_fetch_assoc($result)) {
            $menuName = $row["mName"];
            $menuPrice = $row["mPrice"];
            $quantity = (int)$value;
            $itemTotal = $quantity * $menuPrice;
            $totalPrice += $itemTotal;

            echo "<tbody>
                    <tr>
                        <td>{$menuName}</td>
                        <td>{$quantity}</td>
                        <td>{$itemTotal}元</td>
                    </tr>
                </tbody>";
        }
    }
}

echo "</table></div>";
echo "<h3>總金額: {$totalPrice}元</h3>";
echo "<input type='submit' value='確認並提交訂單' class='button primary fit'>";
echo "</form>";
mysqli_close($link);
?>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>

</div></div></div>
</body>
</html>