<?php
include("include.inc");
?>
<html>
<head>
<meta charset="utf8">
<title>註冊資訊回覆</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">註冊資訊回覆</span>
</div>
</div>
</header>
<div id="main">
<div class="inner">

<?php


//寄歡迎信
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'www/src/Exception.php';
require 'www/src/PHPMailer.php';
require 'www/src/SMTP.php';

$uEmail = $_POST["uEmail"];
//Create an instance; passing true enables exceptions
$mail = new PHPMailer(true);


$uID = $_POST["uID"]; 
$uPWD = $_POST["uPWD"];
$uName = $_POST["uName"];
$uGender = $_POST["uGender"];
$uAge = $_POST["uAge"];

$link = mysqli_connect('localhost','root','','meow');
$check = "SELECT * FROM member WHERE mId= '$uID'";
if(mysqli_num_rows(mysqli_query($link,$check))==0){
    $sql = "INSERT INTO member(mID,mPWD,email,name,gender,age) VALUES ('$uID','$uPWD','$uEmail','$uName','$uGender','$uAge')";
    if(mysqli_query($link,$sql)){
        //寄歡迎信
        try {
            //Server settings
            $mail->SMTPDebug = false;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'a45629751@gmail.com';                     //SMTP username
            $mail->Password   = 'ifug rpiz cbsa ygiu';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS
            $mail->CharSet='utf-8';
            //Recipients
            $mail->setFrom('a45629751@gmail.com', '料理喵王');
            $mail->addAddress($uEmail);     //Add a recipient
            // $mail->addAddress($to);               //Name is optional
            $mail->addReplyTo('a45629751@gmail.com', 'Information');
            // $mail->addCC('cc@example.com');
            // $mail->addBCC('bcc@example.com');
        
            //Attachments
            // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
        
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = "料理喵王";
            $mail->Body    = "歡迎註冊";
            // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        
            $mail->send();
            // echo 'Message has been sent';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

        echo "<h2>註冊成功!3秒後將自動跳轉頁面</h2></br>";
        header("refresh:3;url=login.php");
        exit;
    }
    else{
        echo "Error creating table: ".mysqli_error($link);
    }
}
else{
    echo "<h2>該帳號已有人使用!請重新註冊<br/>3秒後將自動跳轉頁面</h2><br/>";
    header("Refresh:3;url=addAccount.php");
    exit;
}

mysqli_close($link);

?>