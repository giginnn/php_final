<?php
include("include.inc");
$link=mysqli_connect('localhost','root','','meow');
$sql="SELECT * FROM menu";//抓菜單的資料跟價位 設定變數
?>

<html>
<head>
<meta charset="utf8">
<title>料理喵王首頁</title>
</head>
<body>
<center><h1>料理喵王</h1></center>
<hr>
<center><h1>關於網站</h1></center>
<hr>

</body>
</html>