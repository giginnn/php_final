<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="utf8">
        <title>會員登入</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="assets/css/main.css" />
        <noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
    </head>

<body class="is-preload">
    <div id="wrapper">
        <header id="header">
            <div class="inner">
                <div class="logo">
                    <span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">歡迎您登入料理喵王</span>

                    <nav>
                    <ul>
                    <li><a href="#menu">Menu</a></li>
                    </ul>
                    </nav>
                </div>
        </header> 
                    <nav id="menu">
                        <h2>選單</h2>
                        <ul>
                            <li><a href="index.php">首頁</a></li>
                        </ul>
                    </nav>
                   

    <div id="main">
    <div class="inner">
<section>
<h2>會員登入</h2>
<form method="post" action="check.php">
<div class="row gtr-uniform">
<div class="col-12">
<select name="uRole" id="demo-category">
<option value="Member" selected>會員</option>
<option value="Staff">員工</option>
<option value="Boss">老闆</option>
</select>
</div>
<div class="col-6 col-12-xsmall">
<input type="text" name="uID" id="demo-name" value="" placeholder="輸入帳號" />
</div>
<div class="col-6 col-12-xsmall">
<input type="text" name="uPWD" id="demo-email" value="" placeholder="輸入密碼" />
</div>
<div class="col-12">
<ul class="actions fit">
<li><input type="submit" value="登入" class="primary" /></li>
<li><input type="reset" value="重新輸入" /></li>
<li><a href="addAccount.php" class="button primary fit">註冊會員</a></li>
</ul>
</div>
</div>
</form>
</section>
</div>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>