<html>
<head>
<meta charset="utf8">
<title>銷售圓餅圖</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">歷年各品項銷售量圓餅圖</span>
</div>
</div>
</header>
<div id="main">
<div class="inner">

<?php
$link = mysqli_connect('localhost', 'root', '', 'meow');

$sql = "SELECT menuId, mName FROM menu";
$result = mysqli_query($link, $sql);

$menuData = [];

while ($row = mysqli_fetch_assoc($result)) {
    $menuData[$row['menuId']] = ['mName' => $row['mName'], 'quantity' => 0];
}

$sql2 = "SELECT menuId, SUM(quantity) as quantity FROM detail GROUP BY menuId";
$result2 = mysqli_query($link, $sql2);

while ($row2 = mysqli_fetch_assoc($result2)) {
    if (isset($menuData[$row2['menuId']])) {
        $menuData[$row2['menuId']]['quantity'] = $row2['quantity'];
    }
}

include("include.inc");
?>
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['餐點', '銷售量']
          <?php
          foreach ($menuData as $menu) {
            echo ",['" . $menu['mName'] . "', " . $menu['quantity'] . "]";
          }
          ?>
        ]);

        var options = {
          title: '歷年各項餐點銷售總量'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>

<div class='col-12'>
<ul class='actions fit'>
<li><a href = 'bossPage.php' class='button primary'>回上一頁</a></li>
<li><a href = 'linechart.php' class='button'>2024當月銷售額折線圖</a></li>
<li><a href = 'pExcel.php' class='button'>下載成Excel</a></li>
<li><a href = 'pPdf.php' class='button'>下載成PDF</a></li>
<li><a href = 'logout.php' class='button primary'>登出</a></li>
</ul>
</div>
</div></div></div></body></html>