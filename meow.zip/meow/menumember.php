<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<title>料理喵王菜單</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
    <div class="inner">
        <div class="logo">
            <span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王</span>

            <nav>
                <ul>
                <li><a href="#menu">Menu</a></li>
                </ul>
            </nav>

        </div>
    </div>
</header>

<nav id="menu">
    <h2>選單</h2>
        <ul>
            <li><a href="historyorder.php">訂單紀錄</a></li>
            <li><a href="logout.php">登出</a></li>
        </ul>
</nav>

<div id="main">
<div class="inner">
<header>
<h1>歡迎來到料理喵王，這裡提供給您各種早餐午餐晚餐的選擇。<br/></h1>
<p>打開右邊的選單，可以查看之前的訂單紀錄喔。</p>
</header>
<hr>
<section class="tiles">

<?php
//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "SELECT * FROM menu";
//送出查詢
$result = mysqli_query($link,$sql);
//結果轉陣列
while($row = mysqli_fetch_assoc($result)){
    $mName = $row["mName"];
    $mPrice = $row["mPrice"];
    $mPicture = $row["mPicture"];
    echo "<article class='style1'>
    <span class='image'>
    <img src=$mPicture alt='' />
    </span>
    <a href='order.php'>
    <h2>$mName</h2>
    <div class='content'>
    <p>$mPrice/一份</br>點我訂購</p>
    </div>
    </a>
    </article>";
}
?>
<!-- <article class="style1">
<span class="image">
<img src="images/beff.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王A5手切和牛</h2>
<div class="content">
<p>$600/一份</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/lob.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王現撈龍蝦</h2>
<div class="content">
<p>$800/一份</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/chi.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王嫩煎雞胸</h2>
<div class="content">
<p>$500/一份</br>點我訂購</p>
</div>
</a>
</article>
</section>
<section class="tiles">
<article class="style1">
<span class="image">
<img src="images/greendrink.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵草特調</h2>
<div class="content">
<p>$150/一杯</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/ice.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王冰茶</h2>
<div class="content">
<p>$130/一杯</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/nutri.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵喵營養液</h2>
<div class="content">
<p>$110/一杯</br>點我訂購</p>
</div>
</a>
</article>
</section>
<section class="tiles">
<article class="style1">
<span class="image">
<img src="images/sala.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵廚沙拉</h2>
<div class="content">
<p>$160/一份</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/bread.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王手工麵包塊(蛋奶素)</h2>
<div class="content">
<p>$80/2塊</br>點我訂購</p>
</div>
</a>
</article>
<article class="style1">
<span class="image">
<img src="images/humber.jpg" alt="" />
</span>
<a href="order.php">
<h2>喵王經典漢堡排</h2>
<div class="content">
<p>$140/一份</br>點我訂購</p>
</div>
</a>
</article> -->
</section>
</div>
</div>

<!-- Footer -->
<footer id="footer">
<div class="inner">
<h2>企業理念</h2>
<blockquote>料理喵王成立於2099年，有著500年的歷史。我們的<b>500</b>位貓咪大廚嘗遍世界各地的美食，為了讓各位尊貴的喵喵都有享受美食的權利，所以開設這家網路美食店讓喵喵們都有機會品嘗到比肥美的鴿子還美味的食物。
<b>美味、品質、便利</b>是料理喵王的初衷，也是對各位喵喵顧客的承諾。<strong>料理喵王，美味到天堂。</strong>
</blockquote>
<ul class="copyright">
<li>&copy; 料理喵王版權所有</li>
<li>PHP期末專題</li>
</ul>
</div>
</footer>
</div>
<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>