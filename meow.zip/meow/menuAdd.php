<?php
include("include.inc");
?>
<head>
<title>新增菜單頁面</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">新增菜單資訊</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">
<?php

if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="staff" || $_SESSION["check"]=="boss"){
        // echo "成功<br/>";
        // echo "<a href = 'logout.php'>登出</a>";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
}
?>


<form action="menuAddDB.php" method="post">
<h3>輸入新的餐點名稱:<input type = "text" name="mName" value=""></h3><br/>
<h3>輸入新的餐點價格:<input type = "number" name="mPrice" value=""></h3><br/>
<h3>輸入新的餐點的檔案位置(例：images/beff.jpg):<input type = "text" name="mPicture" value=""></h3><br/>
<h3>輸入新的餐點描述:<input type = "text" name="mWord" value=""></h3><br/>
<div class="col-12">
<ul class = "actions fit">
<li><input type = "submit" value="確認新增菜單" class="button primary"></li>
<li><a href ="menuDB.php" class="button">回上一頁</a></li>
<li><a href = "logout.php" class="button fit">登出</a></li>
</ul>
</div>
</form>
</div></div></div></body>