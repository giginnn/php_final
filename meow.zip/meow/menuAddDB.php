<?php
include("include.inc");
?>
<html>
<head>
<title>新增菜單確認頁面</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">新增菜單確認資訊</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">
<?php

if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="staff" || $_SESSION["check"]=="boss"){
        // echo "成功<br/>";
        // echo "<a href = 'logout.php'>登出</a>";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
    }
?>

<?php
$mName = $_POST["mName"];
$mPrice = $_POST["mPrice"];
$mPicture = $_POST["mPicture"];
$mWord = $_POST["mWord"];
 
//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "INSERT INTO menu(mName,mPrice,mPicture,mWord) VALUES('$mName','$mPrice','$mPicture','$mWord')";
//送出查詢
if($result = mysqli_query($link,$sql)){
    echo "<h2><br/>新增成功</h2>";
}
echo "
<ul class='actions fit'>
<li><a href = 'menuDB.php' class='button primary fit'>查看資料庫</a></li>
<li><a href = 'logout.php' class='button fit'>登出</a></li>
</ul>";

mysqli_close($link);
?>
</div></div></div></body></html>