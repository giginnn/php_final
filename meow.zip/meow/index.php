<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<title>料理喵王菜單</title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<!-- Wrapper -->
<div id="wrapper">
<!-- Header -->
<header id="header">
<div class="inner">

<!-- Logo -->
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王</span>

<!-- Nav -->
<nav>
<ul>
<li><a href="#menu">Menu</a></li>
</ul>
</nav>

</div>
</header>

<!-- Menu -->
<nav id="menu">
<h2>選單</h2>
<ul>
<li><a href="index.php">首頁</a></li>
<li><a href="login.php">登入</a></li>
<li><a href="addAccount.php">註冊會員</a></li>
</ul>
</nav>

<!-- Main -->
<div id="main">
<div class="inner">
<header>
<h1>歡迎來到料理喵王，這裡提供給您各種早餐午餐晚餐的選擇。<br/></h1>
<p>還沒成為會員嗎？註冊並登入會員就可以訂購了喔！</p>
</header>
<hr>
<section class="tiles">
<?php
//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "SELECT * FROM menu";
//送出查詢
$result = mysqli_query($link,$sql);
//結果轉陣列
while($row = mysqli_fetch_assoc($result)){
    $mName = $row["mName"];
    $mPrice = $row["mPrice"];
    $mPicture = $row["mPicture"];
    echo "<article class='style1'>
    <span class='image'>
    <img src=$mPicture alt='' />
    </span>
    <a href='login.php'>
    <h2>$mName</h2>
    <div class='content'>
    <p>$mPrice/一份</br>點我訂購</p>
    </div>
    </a>
    </article>";
}
?>

</section>
</div>
</div>

<!-- Footer -->
<footer id="footer">
<div class="inner">
<h2>企業理念</h2>
<blockquote>料理喵王成立於2099年，有著500年的歷史。我們的<b>500</b>位貓咪大廚嘗遍世界各地的美食，為了讓各位尊貴的喵喵都有享受美食的權利，所以開設這家網路美食店讓喵喵們都有機會品嘗到比肥美的鴿子還美味的食物。
<b>美味、品質、便利</b>是料理喵王的初衷，也是對各位喵喵顧客的承諾。<strong>料理喵王，美味到天堂。</strong>
</blockquote>
<ul class="copyright">
<li>&copy; 料理喵王版權所有</li>
<li>PHP期末專題</li>
</ul>
</div>
</footer>
</div>
<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>