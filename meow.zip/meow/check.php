<?php
include("include.inc");
?>
<?php

$uID = $_POST["uID"];
$uPWD = $_POST["uPWD"];
$uRole = $_POST["uRole"];
$link = mysqli_connect('localhost','root','','meow');

if($uRole == "Member"){
    $sql = "SELECT * FROM member";
    $result = mysqli_query($link,$sql);

    while($row = mysqli_fetch_assoc($result)){
        if($uID == $row["mId"] && $uPWD == $row["mPwd"]){         
            $_SESSION["check"] = "member";
            $_SESSION["mId"]=$uID;
            header("Location:menumember.php");
            break;         
        }
        else{
            $_SESSION["check"] = "no";
            header("Location:login.php");
        }
    }
}
elseif($uRole == "Staff"){
    $sql = "SELECT * FROM staff";
    $result = mysqli_query($link,$sql);

    while($row = mysqli_fetch_assoc($result)){
        if($uID == $row["sId"] && $uPWD == $row["sPwd"]){
            $_SESSION["check"] = "staff";
            header("Location:staffPage.php");
            break;
        }
        else{
            $_SESSION["check"] = "no";
            header("Location:login.php");
        }
    }
}
elseif($uRole == "Boss"){
    $sql = "SELECT * FROM boss";
    $result = mysqli_query($link,$sql);

    while($row = mysqli_fetch_assoc($result)){
        if($uID == $row["bId"] && $uPWD == $row["bPwd"]){
            $_SESSION["check"] = "boss";
            header("Location:bossPage.php");
            break;
        }
        else{
            $_SESSION["check"] = "no";
            header("Location:login.php");
        }
    }
}

mysqli_close($link);
?>