<?php
ob_start();
?>

<meta charset="utf-8">
<?php

require_once('TCPDF/tcpdf.php');

//連結資料庫

$link = mysqli_connect('localhost','root','','meow');

$sql = "SELECT DATE_FORMAT(shoppingorder.time, '%m-%d') AS formatted_date, SUM(detail.total) AS total 
        FROM detail 
        NATURAL JOIN shoppingorder 
        GROUP BY formatted_date 
        ORDER BY shoppingorder.time";
$result = mysqli_query($link, $sql);

// // create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// set font
$pdf->SetFont('msungstdlight', '', 10);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->AddPage();

$html = '<table border="1">';
$html.="<tr><td>日期</td><td>總銷售額</td></tr>";

while ($row = mysqli_fetch_assoc($result)) {
    $html.="<tr>";
    $html.= "<td>".$row["formatted_date"]."</td><td>".$row["total"]."</td>";
    $html.= "</tr>";
}
$html.= "</table>";

// // output the HTML content
$pdf->writeHTML($html);
//file send to file address
$path = "/2024本月銷售總額.pdf";
ob_end_clean();
//Close and output PDF document
$pdf->Output(__DIR__ .$path, 'D');
//$pdf->Output($No."-tableinfo.pdf", 'D');
ob_end_flush();

?>