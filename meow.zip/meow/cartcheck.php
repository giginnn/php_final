<?php
include("include.inc");
?>
<html>
<head>
<meta charset="utf8">
<title>收到訂單囉!</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王確認收到訂單</span>
</div>
</div>
</header>
<div id="main">
<div class="inner">

<?php
foreach ($_POST as $key => $value) {
    $_SESSION[$key] = $value;
}

$mId = $_SESSION["mId"] ?? null;

if (!$mId) {
    die("您尚未登入！");
}

$link = mysqli_connect('localhost', 'root', '', 'meow');
mysqli_query($link, "SET time_zone = '+08:00'");

do {
    $shId = rand(10, 99);
    $unuse = "SELECT shId FROM shoppingorder WHERE shId = '$shId'";
    $result = mysqli_query($link, $unuse);
} while (mysqli_num_rows($result) > 0);

date_default_timezone_set('Asia/Taipei');

$sql = "INSERT INTO shoppingorder(shId, time, mId) VALUES ('$shId', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s'), '$mId')";
$sho=mysqli_query($link, $sql);

foreach ($_SESSION as $key => $value) {
    if (strpos($key, 'item_') === 0 && $value > 0) {
        $menuId = substr($key, 5); 
        $quantity = (int)$value;

        $result2 = mysqli_query($link, "SELECT mPrice FROM menu WHERE menuId = $menuId");
        if ($row2 = mysqli_fetch_assoc($result2)) {
            $total = $quantity * $row2["mPrice"];
            $sql2 = "INSERT INTO detail(menuId, shId, quantity, total) VALUES ($menuId, '$shId', $quantity, $total)";
            $dt=mysqli_query($link, $sql2);
        }
    }
}

mysqli_close($link);
echo "<h2>訂單已成功提交！感謝您的訂購。</h2>";

foreach ($_SESSION as $key => $value) {
    if (strpos($key, 'item_') === 0) {
        unset($_SESSION[$key]);
    }
}
?>
<ul class="actions fit">
<li><a href="menumember.php" class="button fit">回到首頁</a></li>
<li><a href="historyorder.php" class="button primary fit">查看訂單紀錄</a></li>
<li><a href ='logout.php' class='button fit'>登出</a></li>
</ul> 
</div>
</div>
</div>
</body>
</html>