
<meta charset="utf-8">  
<?php
header("Pragma: public");
header("Expires: 0");
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Content-type: application/vnd.ms-excel');
header('Content-Disposition: inline; filename="applicant.xls";');
header('Content-Transfer-Encoding: binary');

$link=mysqli_connect(
    'localhost',
    'root',
    '',
    'college'

);

$sql="SELECT * FROM student";
$result=mysqli_query($link,$sql);

echo "<table>";
echo "<tr>";
echo "<td>NO.</td>";
echo "<td>中文姓名</td>";
echo "<td>系所</td>";
echo "</tr>";

while($row=mysqli_fetch_assoc($result)){
    echo "<tr>";
        echo "<td>".$row["No"]."</td><td>".$row["Name"]."</td><td>".$row["Department"]."</td>";
    echo "</tr>";
};

Echo "</table>";

?>