<?php
ob_start();
?>

<meta charset="utf-8">
<?php

require_once('TCPDF/tcpdf.php');

//連結資料庫
$link = mysqli_connect('localhost', 'root', '', 'meow');

$sql = "SELECT menuId, mName FROM menu";
$result = mysqli_query($link, $sql);

$menuData = [];

while ($row = mysqli_fetch_assoc($result)) {
    $menuData[$row['menuId']] = ['mName' => $row['mName'], 'quantity' => 0];
}

$sql2 = "SELECT menuId, SUM(quantity) as quantity FROM detail GROUP BY menuId";
$result2 = mysqli_query($link, $sql2);

while ($row2 = mysqli_fetch_assoc($result2)) {
    if (isset($menuData[$row2['menuId']])) {
        $menuData[$row2['menuId']]['quantity'] = $row2['quantity'];
    }
}

// // create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
// set font
$pdf->SetFont('msungstdlight', '', 10);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->AddPage();

$html = '<table border="1">';
$html.="<tr><td>商品名稱</td><td>銷售總量</td></tr>";

foreach ($menuData as $menu) {
    $html.="<tr>";
    $html.= "<td>".$menu["mName"]."</td><td>".$menu["quantity"]."</td>";
    $html.= "</tr>";
}
$html.= "</table>";

// // output the HTML content
$pdf->writeHTML($html);
//file send to file address
$path = "/歷年各品項銷售量.pdf";
ob_end_clean();
//Close and output PDF document
$pdf->Output(__DIR__ .$path, 'D');
//$pdf->Output($No."-tableinfo.pdf", 'D');
ob_end_flush();

?>