<meta charset="utf-8">

<?php
header("Pragma: public");
header("Expires: 0");
header('Cache-Control: must-revalidate, post-check=0, pre-check=0'); 
header('Content-type: application/vnd.ms-excel');
header('Content-Disposition: inline; filename="歷年各品項銷售量.xls";');
header('Content-Transfer-Encoding: binary');

echo "<table border='1'>";
echo "<tr>";
echo "<td>商品名稱</td>";
echo "<td>銷售總量</td>";
echo "</tr>";

$link = mysqli_connect('localhost', 'root', '', 'meow');

$sql = "SELECT menuId, mName FROM menu";
$result = mysqli_query($link, $sql);

$menuData = [];

while ($row = mysqli_fetch_assoc($result)) {
    $menuData[$row['menuId']] = ['mName' => $row['mName'], 'quantity' => 0];
}

$sql2 = "SELECT menuId, SUM(quantity) as quantity FROM detail GROUP BY menuId";
$result2 = mysqli_query($link, $sql2);

while ($row2 = mysqli_fetch_assoc($result2)) {
    if (isset($menuData[$row2['menuId']])) {
        $menuData[$row2['menuId']]['quantity'] = $row2['quantity'];
    }
}

foreach ($menuData as $menu) {
    echo "<tr>";
    echo "<td>".$menu['mName']."</td>";
    echo "<td>".$menu['quantity']."</td>";
    echo "</tr>";
}
echo "</table>";

?>