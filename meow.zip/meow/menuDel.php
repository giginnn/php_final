<?php
include("include.inc");
?>
<head>
<title>刪除菜單</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">刪除菜單回覆</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">
<?php

if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="staff" || $_SESSION["check"]=="boss"){
        // echo "成功<br/>";
        // echo "<a href = 'logout.php'>登出</a>";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
}
?>

<?php
$menuId = $_GET["menuId"];
// echo $menuId;

//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "DELETE FROM menu WHERE menuId='$menuId'";
//送出查詢
if($result = mysqli_query($link,$sql)){
    echo "<h2><br/>刪除成功</h2>";
}
echo "
<ul class='actions fit'>
<li><a href = 'menuDB.php' class='button primary fit'>查看資料庫</a></li>
<li><a href = 'logout.php' class='button fit'>登出</a></li>
</ul>"

?>
</div></div></div></body>