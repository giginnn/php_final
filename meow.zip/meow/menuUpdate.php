<?php
include("include.inc");
?>
<head>
<title>修改菜單頁面</title>
<meta name="viewport" content="width=deviNumber-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">修改菜單資訊</span>
</div>
</div>
</header>

<div id="main">
<div class="inner">
<?php

if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="staff" || $_SESSION["check"]=="boss"){
        // echo "成功<br/>";
        // echo "<a href = 'logout.php'>登出</a>";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
}
?>

<?php
$menuId = $_GET["menuId"];
// echo $No;
?>

<?php
//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');

//SQL語法
$sql = "SELECT * FROM menu WHERE menuId = '$menuId'";
if($result = mysqli_query($link,$sql)){
    $row=mysqli_fetch_assoc($result);
    $mName = $row["mName"];
    $mPrice = $row["mPrice"];
    $mPicture = $row["mPicture"];
    $mWord = $row["mWord"];
}
?>

<form action="menuUpdateCheck.php" method="post">

<input type="hidden" name="menuId" value="<?php echo $menuId ?>"><br/>
<h2>輸入修改後餐點名稱:<input type="text" name="mName" value="<?php echo $mName ?>"></h2><br/>
<h2>輸入修改後的餐點價格:<input type="number" name="mPrice" value="<?php echo $mPrice ?>"></h2><br/>
<h2>輸入修改後的餐點檔案位置:<input type="text" name="mPicture" value="<?php echo $mPicture ?>"></h2><br/>
<h2>輸入修改後的餐點描述:<input type="text" name="mWord" value="<?php echo $mWord ?>"></h2><br/>
<div class="col-12">
<ul class = "actions fit">
<li><input type = "submit" value="確認修改" class="button primary"></li>
<li><a href ="menuDB.php" class="button fit">回上一頁</a></li>
<li><a href = "logout.php" class="button fit">登出</a></li>
</ul>
</div>
</form>
</div></div></div></body>
