<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf8">
<title>料理喵王訂購頁面</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王美食訂購</span>

<nav>
<ul>
<li><a href="#menu">Menu</a></li>
</ul>
</nav>
</div>
</header>

<nav id="menu">
    <h2>選單</h2>
    <ul>
        <li><a href="menumember.php">首頁</a></li>
        <li><a href="historyorder.php">訂單紀錄</a></li>
        <li><a href="logout.php">登出</a></li>
    </ul>
</nav>

<div id="main">
<div class="inner">
<h2>料理喵王訂購單</h2>
<hr>
<form method="post" action="car.php">

<?php
$mId = $_SESSION["mId"] ?? null;

if (!$mId) {
    die("您尚未登入！");
}

if (isset($_SESSION["mId"])) {
    echo "<h2>".$_SESSION["mId"]. "來點餐吧!</br></h2>";
}

//連結資料庫
$link = @mysqli_connect('localhost','root','','meow');
//SQL語法
$sql = "SELECT * FROM menu";
//送出查詢
$result = mysqli_query($link,$sql);
//結果轉陣列

while ($row = mysqli_fetch_assoc($result)) {
    $menuName = $row["mName"];
    $menuPrice = $row["mPrice"];
    $menuId = $row["menuId"];
    $mPicture = $row["mPicture"];
    $mWord = $row["mWord"];
    $sessionName = "item_" . $menuId;
    $sessionValue = isset($_SESSION[$sessionName]) ? $_SESSION[$sessionName] : 0;

    echo "<div class='box alt'>
		<div class='row gtr-uniform'>
        <div class='col-3'>
        <span class='image fit'>
        <img src=$mPicture>
        </span>
        </div></div></div>";
    echo $menuName . " " . $menuPrice . "元";
    echo "：$mWord";
    echo '<input type="number" name="' . $sessionName . '" min="0" value="' . htmlspecialchars($sessionValue) . '" ></br>';
}

mysqli_close($link);
?>
<div class="col-12">
    <ul class="actions fit">
        <li><input type="submit" value="加入購物車" class="primary"></li>
    </ul>
</div>

</div></div></div>
</form>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>