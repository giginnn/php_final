<?php
include("include.inc");
?>
<html>
<head>
<meta charset="utf8">
<title>老闆數據頁面</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">老闆後臺數據頁面</span>
</div>
</div>
</header>
<div id="main">
<div class="inner">

<?php
if(isset($_SESSION["check"])){
    if($_SESSION["check"]=="boss"){
        //echo "成功<br/>";
        echo "
        <div class='col-12'>
        <ul class='actions fit'>
        <li><a href = 'linechart.php' class='button fit'>查看當季銷售量折線圖</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'piechart.php' class='button fit'>查看各品項銷售圓餅圖</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'menuDB.php' class='button fit'>查看menu資料庫</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'menutest.php' class='button fit'>查看模擬menu</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'mamem.php' class='button fit'>管理會員</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'maho.php' class='button fit'>查看訂單</a></li>
        </ul>
        <ul class='actions fit'>
        <li><a href = 'logout.php' class='button primary'>登出</a></li>
        </ul>
        <h5>註:查看資料後點<u>回上一頁</u>就可以回來此頁面了喔！";
    }
    else{
        header("Location:login.php");
    }
}else{
    header("Location:login.php");
}

?>