<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf8">
<title>料理喵王會員註冊</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
<script>
function validateForm() {
    var radios = document.getElementsByName('uGender');
    var formValid = false;

    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            formValid = true;
            break;
        }
    }

    if (!formValid) {
        alert('請選擇性別');
        return false;
    }

    var email = document.getElementById('demo-email').value;
    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        alert('請輸入有效的電子郵件地址');
        return false;
    }

    return true;
}
</script>
</head>

<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">歡迎您註冊料理喵王</span>

<nav>
<ul>
<li><a href="#menu">Menu</a></li>
</ul>
</nav>

</div>
</header>

<nav id="menu">
<h2>選單</h2>
<ul>
<li><a href="index.php">首頁</a></li>
<li><a href="login.php">登入會員</a></li>
</ul>
</nav>

<div id="main">
<div class="inner">
<section>
<h2>新會員註冊</h2>
<form method="post" action="addAccountDB.php" onsubmit="return validateForm();">
<div class="row gtr-uniform">
<div class="col-6 col-12-xsmall">
<input type="text" name="uName" id="demo-name" value="" required placeholder="輸入姓名" />
</div>
<div class="col-6 col-12-xsmall">
<input type="text" name="uAge" id="demo-age" value="" required placeholder="輸入年紀" />
</div>
<div class="col-12">
<input type="email" name="uEmail" id="demo-email" value="" required placeholder="輸入電子郵件" />
</div>
<div class="col-6 col-12-xsmall">
<input type="text" name="uID" id="demo-id" value="" required placeholder="輸入新帳號名稱" />
</div>
<div class="col-6 col-12-xsmall">
<input type="password" name="uPWD" id="demo-pwd" value="" required placeholder="輸入新帳號密碼" />
</div>
<div class="col-4 col-12-small">
<input type="radio" id="demo-priority-low" name="uGender" value="m">
<label for="demo-priority-low">男性</label>
</div>
<div class="col-4 col-12-small">
<input type="radio" id="demo-priority-high" name="uGender" value="f">
<label for="demo-priority-high">女性</label>
</div>

<div class="col-12">
<ul class="actions fit">
<li><input type="reset" value="重新輸入"></li>
<li><input type="submit" value="送出資料" class="primary"></li>
</ul>
</div>
</div>
</div>
</form>
</div>
</div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
