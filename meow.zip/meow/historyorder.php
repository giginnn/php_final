<?php
include("include.inc");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf8">
<title>料理喵王訂購紀錄</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="assets/css/main.css" />
<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload">
<div id="wrapper">
<header id="header">
<div class="inner">
<div class="logo">
<span class="symbol"><img src="images/catlogo.png" alt="" /></span><span class="title">料理喵王訂購紀錄</span>

<nav>
<ul>
<li><a href="#menu">Menu</a></li>
</ul>
</nav>
</div>
</header>

<nav id="menu">
<h2>選單</h2>
<ul>
<li><a href="menumember.php">首頁</a></li>
<li><a href="order.php">訂購頁面</a></li>
<li><a href="logout.php">登出</a></li>
</ul>
</nav>

<div id="main">
<div class="inner">


<?php
$mId = $_SESSION["mId"] ?? null;

if (!$mId) {
    die("您尚未登入！");
}
$link = mysqli_connect('localhost', 'root', '', 'meow');

$sql = "
    SELECT 
        so.shId,
        DATE_FORMAT(so.time, '%Y-%m-%d %H:%i') AS formatted_date,
        d.menuId,
        d.quantity,
        d.total,
        m.mName
    FROM 
        shoppingorder AS so
    JOIN 
        detail AS d ON so.shId = d.shId
    JOIN 
        menu AS m ON d.menuId = m.menuId
    WHERE 
        so.mId = '$mId'
    ORDER BY 
        formatted_date DESC
";

$result = mysqli_query($link, $sql);

$Data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $Data[] = [
        '訂單編號' => $row['shId'],
        '餐點名稱' => $row['mName'],
        '數量' => $row['quantity'],
        '總金額' => $row['total'],
        '下單時間' => $row['formatted_date']
    ];
}

mysqli_close($link);
?>


<h2><?php echo $mId ?>的訂單紀錄</h2>
<div class='table-wrapper'>
    <table>
        <thead>
            <tr>
                <th>訂單編號</th>
                <th>餐點名稱</th>
                <th>數量</th>
                <th>總金額</th>
                <th>下單時間</th>
            </tr>
        </thead>

        <tbody>
            <?php foreach ($Data as $order): ?>
            <tr>
                <td><?php echo htmlspecialchars($order['訂單編號']); ?></td>
                <td><?php echo htmlspecialchars($order['餐點名稱']); ?></td>
                <td><?php echo htmlspecialchars($order['數量']); ?></td>
                <td><?php echo htmlspecialchars($order['總金額']."元"); ?></td>
                <td><?php echo htmlspecialchars($order['下單時間']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<h4>小貼示：點開右上角的<u>選單</u>就可以登出囉！</h4>  

</div></div></div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/browser.min.js"></script>
<script src="assets/js/breakpoints.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
</body></html>
